## lakshya90.github.io
### Step 1
#### git clone https://github.com/lakshya90/lakshya90.github.io.git

### Step 2
#### 1. Replace all “Lakshya Sivaramakrishnan” with your name. 
#### 2. Add two of your pictures for background image and profile picture.
#### 3. Add your relevant links to LinkedIn, Twitter and Github.
#### 4. Edit your details in About, Resume, Testimonials and Contact section.

### Step 3
#### 1. Go to github.com and create a repo named <your user_name>.github.io 
#### 2. On your terminal, git init
#### 3. git add assets/ index.html
#### 4. git commit -m “Initial Commit”
#### 5. git remote add origin <url>
#### 6. git push -u origin master
